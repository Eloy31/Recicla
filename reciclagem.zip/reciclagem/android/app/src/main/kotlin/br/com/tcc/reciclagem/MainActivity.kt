package br.com.tcc.reciclagem

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
