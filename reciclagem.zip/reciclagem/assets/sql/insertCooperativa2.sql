INSERT INTO public.cooperativa(
	id, identificador, setor_habitacional, responsavel, contato, cep, observacao, latitude, longitude)
	VALUES (2, 'Asgard', 'Águas Claras', 'Gammer', '99999-9999', '68500-000', 'lugar para jogar', -15.842655901161491, -48.023003271849184);