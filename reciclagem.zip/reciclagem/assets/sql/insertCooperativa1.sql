INSERT INTO public.cooperativa(
	id, identificador, setor_habitacional, responsavel, contato, cep, observacao, latitude, longitude)
	VALUES (1, 'bonanza', 'Vicente Pires', 'Padeiro', '99999-9999', '68500-000', 'lugar para comer', -15.806321654409587, -48.039997747408236);